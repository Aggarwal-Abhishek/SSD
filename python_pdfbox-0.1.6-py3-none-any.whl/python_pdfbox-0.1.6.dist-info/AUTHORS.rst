.. -*- rst -*-

Authors
-------
This software was written and packaged by Lev E. Givon [1]_.

Special thanks are due to the following parties for their contributes:

- `Fakabbir Amin <https://github.com/fakabbir>`_ - support for PDF to image conversion command.
- `Ivan Zvonkov <https://github.com/ivanzvonkov>`_ - support for image extraction command.
- `Uday Krishna <https://github.com/udaykrishna>`_ - Python 3.4 compatibility improvements.

.. [1] https://lebedov.github.io
